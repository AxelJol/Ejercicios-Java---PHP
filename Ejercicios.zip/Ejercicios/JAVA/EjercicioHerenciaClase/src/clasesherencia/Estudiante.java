package clasesherencia;

public class Estudiante extends Persona {

        
    private String carrera; // propiedad
    private int legajo; // propiedad

    public Estudiante () { // constructor
    }
    public String getCarrera () {// asesor a carrera 
        return carrera;
    }
    public void setCarrera (String val) { // mutador de carrera 
        this.carrera = val;
    }
    public int getLegajo () { // asesor a legajo 
        return legajo;
    }
    public void setLegajo (int val) { // mutador de legajo 
        this.legajo = val;
    }
}