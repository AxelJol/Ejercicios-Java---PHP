package clases;
public class Persona {
    private String nombre; // propiedad
    private int edad; // propiedad

    
    public Persona () { // constructor
    }

    public int getEdad () { // asesor a edad 
        return edad;
    }
    public void setEdad (int val) { // mutador de edad 
        this.edad = val;
    }
    public String getNombre () { // asesor a nombre 
        return nombre;
    }
    public void setNombre (String val) { // mutador de nombre 
        this.nombre = val;
    }
}
