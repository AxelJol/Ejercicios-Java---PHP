package clases;
public class Profesor extends Persona {
    private String materia; // propiedad
    private String cargo; // propiedad
    public Profesor () {// constructor
    }
    public String getCargo () { // asesor de cargo 
        return cargo;
    }
    public void setCargo (String val) { // mutador de cargo 
        this.cargo = val;
    }
    public String getMateria () { // asesor de materia 
        return materia;
    }
    public void setMateria (String val) {// mutador de materia 
        this.materia = val;
    }
}